<?php include("header.php");header_insert(); ?>


<div id="social">
	<strong>Follow us:</strong><br><br>
	<a href="https://www.facebook.com/pages/SA-Gymnastics/786535728041807"><img src="images/facebook.png" alt="Like us on facebook"></a>
	<a class="left_padding" href="https://twitter.com/sagymnastics123"><img src="images/twitter.png" alt="Follow us on twitter"></a>
	</ul>
</div>
		

<h1>Gymnastics Parties</h1>

<p><a href="Party_flyer.pdf">Click here to open the leaflet in a new window</a><br><br></p>

<iframe width="100%" height="700" src="Party_flyer.pdf"></iframe>
                        

			
<?php include("footer.php");footer_insert(); ?>