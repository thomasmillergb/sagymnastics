<?php include("header.php");header_insert();?>

<div id="social">
	<strong>Follow us:</strong><br><br>
	<a href="https://www.facebook.com/pages/SA-Gymnastics/786535728041807"><img src="images/facebook.png" alt="Like us on facebook"></a>
	<a class="left_padding" href="https://twitter.com/sagymnastics123"><img src="images/twitter.png" alt="Follow us on twitter"></a>
	</ul>
</div>
		

<h1>Enrol</h1>

<?php
	if (isset($_POST['name'])) {
		
		$email_message = "Form details below.\n\n";
 
     
 
	    function clean_string($string) {
	 
	      $bad = array("content-type","bcc:","to:","cc:","href");
	 
	      return str_replace($bad,"",$string);
	 
	    }
	 
	     
	 
	    $email_message .= "Name: ".clean_string($_POST['name'])."\n";
	 
	    $email_message .= "DOB: ".clean_string($_POST['dob'])."\n";
	 
	    $email_message .= "Gender: ".clean_string($_POST['gender'])."\n";
	 
	    $email_message .= "Address: ".clean_string($_POST['address'])."\n";
	 
	    $email_message .= "Phone: ".clean_string($_POST['phone'])."\n";
	    
	    $email_message .= "Email: ".clean_string($_POST['email'])."\n";
	    
		$email_message .= "Parent: ".clean_string($_POST['parent'])."\n";
	 
		$email_message .= "Class: ".clean_string($_POST['class'])."\n";
		
		$email_message .= "Date: ".clean_string($_POST['date'])."\n";
		
		$email_message .= "Time: ".clean_string($_POST['time'])."\n";
		
		$email_message .= "Needs: ".clean_string($_POST['needs'])."\n";
		
		$email_message .= "Info: ".clean_string($_POST['info'])."\n";
	 
		// create email headers
		 
		$headers = 'From: '.clean_string($_POST['email'])."\r\n".
		 
		'Reply-To: '.clean_string($_POST['email'])."\r\n" .
		 
		'X-Mailer: PHP/' . phpversion();
		 
		@mail("admin@sagymnasts.co.uk", "Enrolment form", $email_message, $headers);
		@mail("enrol@sagymnastics.co.uk", "Enrolment form", $email_message, $headers);
		@mail("membership@sagymnastics.co.uk", "Enrolment form", $email_message, $headers);
		
		
		
		echo "Thank you for your enrolment. We will be in contact shortly.";
		
		
	} else {
	
?>






<form method="post" action="enroll.php">
	
	<div class="row clearfix" style="margin-top:80px;">
		<div class="widget_box_transparent one half double-padded">
			<h2>Personal Details</h2>
			<p>
				Name:<br>
				<input type="text" name="name" value="" size="40" id="name">
			</p>
			<p>
				Date of Birth:<br>
				<input type="date" name="dob" value="">
			</p>
			<p>
				Gender:<br>
				<select name="gender" id="gender" aria-invalid="false"><option value="Male">Male</option><option value="Female">Female</option></select>
			</p>
			<p>
				Address:<br>
				<input type="text" name="address" value="" size="40" id="address">
			</p>
			<p>
				Home Telephone:<br>
				<input type="text" name="phone" value="" size="40" id="phone">
			</p>
			<p>
				Mobile:<br>
				<input type="text" name="mobile" value="" size="40" id="mobile">
			</p>
			<p>
				Email:<br>
				<input type="email" name="email" value="" size="40" id="email">
			</p>
			<p>
				Parent/Guardian Name:<br>
				<input type="text" name="parent" value="" size="40" id="parent">
			</p>
		</div>
		<div class="widget_box_transparent one half double-padded">
			<h2>Course Details</h2>
			<p>
				Class Type:<br>
				<select name="class"><option value="Baby Cubs">Baby Cubs</option><option value="Tumblin Tigers">Tumblin Tigers</option><option value="Leapin Lions">Leapin Lions</option><option value="Recreational Gymnastics">Recreational Gymnastics</option><option value="Development Group">Development Group</option><option value="Youth Night">Youth Night</option><option value="Adult Gymnastics">Adult Gymnastics</option></select>
			</p>
			<p>
				Date:<br>
				<input type="date" name="date" value="">
			</p>
			<p>
				Time:<br>
				<input type="text" name="time" value="" size="40">
			</p>
			<p>
				Special Medical Needs:<br>
				<input type="text" name="needs" value="" size="40">
			</p>
			<p>
				Additional Information:<br>
				<textarea name="info" cols="40" rows="10"></textarea>
			</p>
			<p>
				<input type="submit" value="Send">
			</p>
		</div>
	</div>
                        
</form>
			
<?php 
	
	}
	

	include("footer.php");footer_insert(); 

?>