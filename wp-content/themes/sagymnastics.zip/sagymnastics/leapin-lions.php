<?php include("header.php");header_insert(); ?>


<div class="cbp_widget_box one whole double-padded cubstigerslions ">
<span>Educational</span> <span>Physical</span> <span>Creative</span> <span>Intellectual</span> <span>Lingual</span> <span class="last">Social</span><p></p>
<p>This class is a <strong>structured and totally independent class</strong> for children <strong>aged 3 - 4 1/2 years.</strong></p>
<p>Here they will be introduced to the fundamental skills of gymnastics in a fun and exciting environment. Also to learn how to follow directions from our <strong>British Gymnastics</strong> qualified coaches and explore our equipment independently.</p>
<p>A great way to make friends through exercise and play.</p>
<h5>Class times:</h5>
<table>
<thead>
<tr>
<td>Mon</td>
<td>Tue</td>
<td>Wed</td>
<td>Thur</td>
<td>Fri</td>
<td>Sat</td>
</tr></thead>


<tbody>
<tr>
<td>10:45 - 11:30am</td>
<td>12:45 - 13:30pm<br>13:45 - 14:30pm</td>
<td>9:45 - 10:30am</td>
<td>12:45 - 13:30pm<br>13:45 - 14:30pm</td>
<td>10:45 - 11:30am</td>
<td>9:00 - 9:45am</td>
</tr>
</tbody>
</table>
</div>
<img src="images/lion.png" alt="lion" width="423" height="224" class="classimage" style="margin-top:-60px"><br>

			
<?php include("footer.php");footer_insert(); ?>