<?php include("header.php");header_insert(); ?>


<div class="cbp_widget_box one whole double-padded recreational ">
<img src="images/fantastic.png" alt="fantastic" width="399" height="225" class="classimage size-full wp-image-209">
<h2>Recreational</h2>
<p>Fun and exciting gymnastics sessions for <strong>girls and boys ages 4-15 years</strong>.</p>
<p>Come and enjoy bouncing, balancing and swinging in our <strong>NEW</strong> gymnastics facility. Here you will learn the fundamental skills of gymnastics with goals and targets to achieve as well as making friends and having fun.</p>
<p>There are also opportunities each term for gymnasts to obtain achievement certificates for all their hard work!</p>
<h4>Class times:</h4>
<table>
<thead>
<tr>
<td>Mon</td>
<td>Tues</td>
<td>Wed</td>
<td>Thur</td>
<td>Fri</td>
<td>Sat</td>
</tr></thead>
<tbody>
<tr>
<td>16:30 - 17:45pm</td>
<td>16:30 - 17:45pm</td>
<td>16:30 - 17:45pm</td>
<td>16:30 - 17:45pm</td>
<td>16:30 - 17:45pm</td>
<td>
10:00 - 11:15am<br>
13:30 - 12:45pm
</td>
</tr>
</tbody>
</table>
<p><img src="http://www.sa-gymnastics.co.uk/wp-content/uploads/2014/05/recreation.png" alt="recreation" width="100%" class="aligncenter size-full wp-image-210"></p></div>


<div class="cbp_widget_box one whole double-padded recreational ">
<img src="http://www.sa-gymnastics.co.uk/wp-content/uploads/2014/05/advanced.png" alt="advanced" width="367" height="200" class="classimage size-full wp-image-196"><p></p>
<h2>Advanced</h2>
<p>For the more established gymnast who can work towards two piece competitions (floor and vault)</p>
<p><strong>Advanced gymnasts by selection only</strong></p>
<h4>Class times:</h4>
<table>
<thead>
<tr>
<td>Tues</td>
<td>Thur</td>
</tr></thead>
<tbody>
<tr>
<td>17:00 - 19:00</td>
<td>17:00 - 19:00</td>
</tr>
</tbody>
</table>
</div>

			
<?php include("footer.php");footer_insert(); ?>