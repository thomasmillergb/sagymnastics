<?php

	function header_insert() {
	
		?>
		
			<html>
				<head>
					<title>SA Gymnastics</title>
					<meta name="description" content="">
					<meta name="keywords" content="SA Gymnastics">
					<link rel="icon" type="image/png" href="images/favicon.png">
					<link rel="stylesheet" type="text/css" href="css/main.css">
					<script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
					<script src="js/main.js"></script>
				</head>
				<body>
					<div id="center_wrapper">
						<header>
							<div class="shape shape_left"></div>
							<a class="logo" href="http://www.sagymnastics.co.uk/" rel="home">
								<img src="images/header_logo.png" alt="SA Gymnastics">
							</a>
							<div class="shape shape_right"></div>
							<nav>
								<div class="table">
									<ul>
										<li><a href="index.php">Home</a></li>
										<li><a href="about.php">About</a></li>
										<li><a href="classes.php">Classes</a></li>
										<li><a href="parties.php">Parties</a></li>
										<li><a href="enroll.php">Enrol</a></li>
										<li><a href="contactus.php">Contact us</a></li>
									</ul>
								</div>
							</nav>
						</header>
						<div id="inner_content">
		<?php
	
	}
?>
