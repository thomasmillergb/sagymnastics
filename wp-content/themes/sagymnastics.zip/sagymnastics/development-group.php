<?php include("header.php");header_insert(); ?>


<div class="cbp_widget_box one whole double-padded development ">
<img src="images/dev-1.png" alt="dev-1" width="245" height="239" style="margin:0 auto; display: block;"><p></p>
<p>Advanced group for gymnasts working towards <strong>National Club Grades</strong> and <strong>Elite Grades.</strong></p>
<p>This is a pathway to develop your child's potential towards <strong>National</strong> and <strong>Elite</strong> club gymnastics.</p>
<p><strong>Gymnasts by selection only.</strong></p>
<h4>Class times:</h4>
<table>
<thead>
<tr>
<td>Mon</td>
<td>Wed</td>
<td>Thur</td>
<td>Sat</td>
</tr></thead>
<tbody>
<tr>
<td>17:00 - 20:00</td>
<td>17:00 - 20:00</td>
<td>17:00 - 20:00</td>
<td>17:00 - 20:00</td>
</tr>
</tbody>
</table>
<p><img src="images/development.png" alt="development" width="100%" class="aligncenter size-full wp-image-211"></p></div>
			
<?php include("footer.php");footer_insert(); ?>