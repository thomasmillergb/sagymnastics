<?php include("header.php");header_insert(); ?>



<div class="cbp_widget_box one whole double-padded cubstigerslions ">
<span>Educational</span> <span>Physical</span> <span>Creative</span> <span>Intellectual</span> <span>Lingual</span> <span class="last">Social</span><br>
These sessions are for children aged between <strong>12 months and 2 years with parental supervision</strong>. Here your child can develop social skills and interact with other children, follow directions and improve their motor skills.<p></p>
<p>These sessions will have British Gymnastics Qualified Coaches present while you enjoy the use of our brand new facility and spend quality time with your child though exercise and play!</p>
<h5>Class times:</h5>
<table>
<thead>
<tr>
<td>Mon</td>
<td>Tues</td>
<td>Wed</td>
<td>Thur</td>
<td>Fri</td>
</tr></thead>
<tbody>
<tr>
<td>13:45 - 14:30pm</td>
<td>9:45 - 10:30am</td>
<td>10:45 - 11:30am</td>
<td>9:45 - 10:30am</td>
<td>13:45 - 14:30pm</td>
</tr>
</tbody>
</table>
</div>
<img src="images/cubs2.png" alt="cubstigerslions" width="423" height="247" class="classimage">

			
<?php include("footer.php");footer_insert(); ?>