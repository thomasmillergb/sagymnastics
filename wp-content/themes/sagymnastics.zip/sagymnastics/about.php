<?php include("header.php");header_insert(); ?>

<h1>
    About
</h1>
<div class="row clearfix">
    <div class="widget_box one half double-padded team ">
        <img class="aligncenter size-full wp-image-29"
             src="images/sarah.jpg"
             alt="sarah"
             width="324">
        <p></p>
        <h2>
            Sarah Luck (n&eacute;e Attwell)
        </h2>
        <p>
            Sarah was British National Grades Champion in 1986 and 1987. In 1988 she trained with the USSR Olympic Squad at Vladimir College in Russia and represented Great Britain against various European Countries. On retiring from competition, she took up coaching and trained gymnasts involved in the Junior and Senior GB Gymnastics Squads. She is now an Olympic Master coach.
        </p>
        <p>
            In 2000 Sarah was appointed Manager of Liverpool Gymnastics Club's Centre of Excellence where she taught many of the countries top gymnasts. In 2008 she took her gymnast Hannah Whelan, and two others with Team GB from Liverpool GC to the Beijing Olympics.
        </p>
        <p>
            Sarah started her own business in 2009 as a regular gymnastics coach, and runs regular Gym classes. She also provides coaching support from Gym Clubs, and teaches gymnastics both to children and PE teachers in schools.
        </p>
        <p>
            Sarah is also contracted by British Gymnastics as a Pathway performance Coach She runs Clinics for Coaches and Camps for children, to develop and guide the youngsters through to the Elite Squad system for GB's future stars.
            <br>
        </p>
    </div>
    <div class="widget_box one half double-padded team ">
        <img class="aligncenter size-full wp-image-30"
             src="images/berenice.jpg"
             alt="berenice"
             width="324">
        <p></p>
        <h2>
            Berenice Webb
        </h2>
        <p>
            Berenice Webb started her gymnastics career back in 2002. Firstly coaching recreational gymnastics a few days a week as a volunteer. Berenice enjoyed the sport so much that in 2006 she decided to take a Level 3 (Club Coach) qualification, which she passed with flying colours.
        </p>
        <p>
            As her career in coaching progressed Berenice decided to expand her qualifications by taking an exam in preschool gymnastics. With this under her belt she set up her own preschool classes which were extremely popular.
        </p>
        <p>
            In 2013 Sarah and Berenice joined forces and started to run a few preschool classes together, Baby Cubs and Tumblin Tigers, which have been a huge success.
        </p>
        <p>
            Berenice is CRB checked and holds a safe guarding certificate to work with children and has also got Welfare Office status.
            <br>
        </p>
    </div>
</div>
<?php include("footer.php");footer_insert(); ?>
