<?php include("header.php");header_insert(); ?>

<div class="cbp_widget_box one whole double-padded development " style="font-size:1.5em">
<img style="width: 600px; height: auto; margin-top: 15px;margin:0 auto; display: block;" src="images/adult.png" alt="adult" width="792" height="272"><p></p>
<p><strong>ADULT <span style="color: #9c1d28;margin:0;">GYMNASTICS</span></strong> night is open to anyone over 16 years of age. It's a fun and informal session for adults whether you have done gymnastics before or just fancy having a go!</p>
<p>You will have use of the whole gym, sprung floor area, vault, bars, beam and trampoline in a safe and controlled environment.</p>
<p>There will be a fully qualified member of staff to take you through a warm up and stretch which everyone must take part in, but then you have free time to experiment to your heart's content.</p>
<p>The coach will be available throughout the session if you require technical help, advice or support.</p>
<p style="margin:0 auto -23px auto; display: block;"><img class="aligncenter size-full wp-image-201" src="http://www.sa-gymnastics.co.uk/wp-content/uploads/2014/05/adult-3.png" alt="adult-3" width="716" height="268"></p>
</div>
			
<?php include("footer.php");footer_insert(); ?>