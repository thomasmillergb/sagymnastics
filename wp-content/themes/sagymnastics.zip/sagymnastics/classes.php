<?php include("header.php");header_insert(); ?>
<h1>
    Classes
</h1>

<div class="clearfix">
	<a class="class_links" href="baby-cubs.php"><img src="images/cubs1.png" alt="Cubs" width="320" height="360" style="margin-left:-70px;"></a>
	<a class="class_links" href="tumblin-tigers.php"><img src="images/tigers1.png" alt="Tigers" width="320" height="360"></a>
	<a class="class_links" href="leapin-lions.php"><img src="images/lions.png" alt="Lions" width="320" height="360" style="margin-right:-100px;"></a>
</div>

<div class="clearfix">         
	<a class="class_links" href="recreational-gymnastics.php" style="margin-right:20px;"><img src="images/Recreational_gymnastics.jpg" alt="Recreational gymnastics" width="437" height="249" style="margin-left:-20px;"></a>
	<a class="class_links" href="development-group.php"><img src="images/Development_group.jpg" alt="Development Group" width="437" height="249" style="margin-right:-20px;"></a>
</div>

<div class="clearfix">         
	<a class="class_links" href="youth-night.php" style="margin-right:20px;"><img src="images/Youth_night.jpg" alt="Youth Night" width="301" height="266"  style="margin-left:-50px;"></a>
	<a class="class_links" href="adult-gymnastics.php" style="margin-right:20px;"><img src="images/Adult_gymnastics.jpg" alt="Adult Gymnastics" width="300" height="266"></a>
    <a class="class_links" href="parties.php"><img src="images/Gymnastics_parties.jpg" alt="Gymnastics Parties" width="300"  height="266" style="margin-right:-100px;"></a>
</div>

<?php include("footer.php");footer_insert(); ?>