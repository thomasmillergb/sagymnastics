<?php

	function footer_insert() {
	
		?>
						</div>
						<div id="small_logo"></div>
						<div id="moreinfo">
							For more info please email us<br>
							<a href="mailto:admin@sagymnastics.co.uk">admin@sagymnastics.co.uk</a>
						</div>
					</div>
					<footer>
						Copyright &copy; 2014 SA Gymnastics
					</footer>
				</body>
			</html>
				
		
		<?php
	
	}
?>
