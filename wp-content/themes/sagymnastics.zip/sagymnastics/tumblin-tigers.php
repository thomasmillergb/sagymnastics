<?php include("header.php");header_insert(); ?>


<div class="cbp_widget_box one whole double-padded cubstigerslions ">
<span>Educational</span> <span>Physical</span> <span>Creative</span> <span>Intellectual</span> <span>Lingual</span> <span class="last">Social</span><p></p>
<p>These sessions are for children aged <strong>2-3 years with Parental participation in a semi structured class.</strong></p>
<p>Together you can explore and enjoy our new equipment and facility alongside our British Gymnast Qualified coaches. They will help you with activities that are educational, physical, creative, lingual and social but most importantly a great way to spend quality time with your child in a safe and fun environment.</p>
<h5>Class times:</h5>
<table>
<thead>
<tr>
<td>Mon</td>
<td>Tues</td>
<td>Thur</td>
<td>Fri</td>
</tr></thead>
<tbody>
<tr>
<td>
9:45 - 10:30am<br>
12:45 - 13.30pm
</td>
<td>10:45 - 11:30am</td>
<td>9:45 - 10:30am</td>
<td>
9:45 - 10:30am<br>
12:45 - 13.30pm
</td>
</tr>
</tbody>
</table>
</div>
<img src="http://www.sa-gymnastics.co.uk/wp-content/uploads/2014/05/tigers2.png" alt="tigers" width="423" height="224" class="classimage">

			
<?php include("footer.php");footer_insert(); ?>